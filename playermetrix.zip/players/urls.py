from django.urls import path
from . import views

urlpatterns = [
    path('players/', views.players, name='players'),
    path('test/', views.tester, name='tester'),
    path('events/', views.events, name='events'),
    path('players/<slug:slug>', views.playerdetail, name='playerdetail'),
    path('', views.index, name='index'),
]