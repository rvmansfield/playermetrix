from django.contrib import admin
from members.models import Profile

admin.site.register(Profile)
